<?php

define('BASEURL', 'http://localhost:8000/identify/public');
