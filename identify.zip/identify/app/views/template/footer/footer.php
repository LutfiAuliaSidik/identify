    <footer class="container-footer">
      <div class="footer">
        <h1>identify</h1>
      </div>
    </footer>
    <script src="<?= BASEURL; ?>/js/script.js"></script>
  </body>
</html>
