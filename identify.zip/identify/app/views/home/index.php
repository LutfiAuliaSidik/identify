<section class="container-section">
  <main>
    <div class="search">
      <form method="post" action="">
        <input type="text" name="search" autocomplete="off">
      </form>
    </div>
  </main>
  <main class="container-list-identify">
    <div class="list-identify">
      <a href="<?= BASEURL; ?>/../home/detail/"><img src="<?= BASEURL; ?>/image/profile/lutfi.jpg" alt=""></a>
      <div class="text-identify">
        <p>lutfi aulia sidik</p>
        <p>17 thn</p>
        <p>55%</p>
      </div>
      <i class="fa-solid fa-circle-info"></i>
      <div class="container-info">
        <div class="info">
          <span></span>
          <p></p>
        </div>
      </div>
    </div>
    <div class="list-identify">
      <a href="<?= BASEURL; ?>/../home/detail/"><img src="<?= BASEURL; ?>/image/profile/lutfi.jpg" alt=""></a>
      <div class="text-identify">
        <p>lutfi aulia sidik</p>
        <p>17 thn</p>
        <p>99%</p>
      </div>
      <i class="fa-solid fa-circle-info"></i>
      <div class="container-info">
        <div class="info">
          <span></span>
          <p></p>
        </div>
      </div>
    </div>
    <div class="list-identify">
      <a href="<?= BASEURL; ?>/../home/detail/"><img src="<?= BASEURL; ?>/image/profile/lutfi.jpg" alt=""></a>
      <div class="text-identify">
        <p>lutfi aulia sidik</p>
        <p>17 thn</p>
        <p>60%</p>
      </div>
      <i class="fa-solid fa-circle-info"></i>
      <div class="container-info">
        <div class="info">
          <span></span>
          <p></p>
        </div>
      </div>
    </div>
    <div class="list-identify">
      <a href="<?= BASEURL; ?>/../home/detail/"><img src="<?= BASEURL; ?>/image/profile/lutfi.jpg" alt=""></a>
      <div class="text-identify">
        <p>lutfi aulia sidik</p>
        <p>17 thn</p>
        <p>79%</p>
      </div>
      <i class="fa-solid fa-circle-info"></i>
      <div class="container-info">
        <div class="info">
          <span></span>
          <p></p>
        </div>
      </div>
    </div>
    <div class="list-identify">
      <a href="<?= BASEURL; ?>/../home/detail/"><img src="<?= BASEURL; ?>/image/profile/lutfi.jpg" alt=""></a>
      <div class="text-identify">
        <p>lutfi aulia sidik</p>
        <p>17 thn</p>
        <p>19%</p>
      </div>
      <i class="fa-solid fa-circle-info"></i>
      <div class="container-info">
        <div class="info">
          <span></span>
          <p></p>
        </div>
      </div>
    </div>
    <div class="list-identify">
      <a href="<?= BASEURL; ?>/../home/detail/"><img src="<?= BASEURL; ?>/image/profile/lutfi.jpg" alt=""></a>
      <div class="text-identify">
        <p>lutfi aulia sidik</p>
        <p>17 thn</p>
        <p>44%</p>
      </div>
      <i class="fa-solid fa-circle-info"></i>
      <div class="container-info">
        <div class="info">
          <span></span>
          <p></p>
        </div>
      </div>
    </div>
    <div class="list-identify">
      <a href="<?= BASEURL; ?>/../home/detail/"><img src="<?= BASEURL; ?>/image/profile/lutfi.jpg" alt=""></a>
      <div class="text-identify">
        <p>lutfi aulia sidik</p>
        <p>17 thn</p>
        <p>55%</p>
      </div>
      <i class="fa-solid fa-circle-info"></i>
      <div class="container-info">
        <div class="info">
          <span></span>
          <p></p>
        </div>
      </div>
    </div>
    <div class="list-identify">
      <a href="<?= BASEURL; ?>/../home/detail/"><img src="<?= BASEURL; ?>/image/profile/lutfi.jpg" alt=""></a>
      <div class="text-identify">
        <p>lutfi aulia sidik</p>
        <p>17 thn</p>
        <p>99%</p>
      </div>
      <i class="fa-solid fa-circle-info"></i>
      <div class="container-info">
        <div class="info">
          <span></span>
          <p></p>
        </div>
      </div>
    </div>
    <div class="list-identify">
      <a href="<?= BASEURL; ?>/../home/detail/"><img src="<?= BASEURL; ?>/image/profile/lutfi.jpg" alt=""></a>
      <div class="text-identify">
        <p>lutfi aulia sidik</p>
        <p>17 thn</p>
        <p>60%</p>
      </div>
      <i class="fa-solid fa-circle-info"></i>
      <div class="container-info">
        <div class="info">
          <span></span>
          <p></p>
        </div>
      </div>
    </div>
    <div class="list-identify">
      <a href="<?= BASEURL; ?>/../home/detail/"><img src="<?= BASEURL; ?>/image/profile/lutfi.jpg" alt=""></a>
      <div class="text-identify">
        <p>lutfi aulia sidik</p>
        <p>17 thn</p>
        <p>79%</p>
      </div>
      <i class="fa-solid fa-circle-info"></i>
      <div class="container-info">
        <div class="info">
          <span></span>
          <p></p>
        </div>
      </div>
    </div>
    <div class="list-identify">
      <a href="<?= BASEURL; ?>/../home/detail/"><img src="<?= BASEURL; ?>/image/profile/lutfi.jpg" alt=""></a>
      <div class="text-identify">
        <p>lutfi aulia sidik</p>
        <p>17 thn</p>
        <p>19%</p>
      </div>
      <i class="fa-solid fa-circle-info"></i>
      <div class="container-info">
        <div class="info">
          <span></span>
          <p></p>
        </div>
      </div>
    </div>
    <div class="list-identify">
      <a href="<?= BASEURL; ?>/../home/detail/"><img src="<?= BASEURL; ?>/image/profile/lutfi.jpg" alt=""></a>
      <div class="text-identify">
        <p>lutfi aulia sidik</p>
        <p>17 thn</p>
        <p>44%</p>
      </div>
      <i class="fa-solid fa-circle-info"></i>
      <div class="container-info">
        <div class="info">
          <span></span>
          <p></p>
        </div>
      </div>
    </div>
  </main>
</section>
